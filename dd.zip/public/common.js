export const arr = [10, 20, 30, 40];

const info = { loc: "seoul" };
const arr2 = [100, 2000, 300, 400];
export { arr2, getName, info };

alert("common.js");
function getName() {
  return "getName함수";
}
