import { arr, arr2, getName, info } from "./common.js";
arr2[1] = 88;
console.log("go:", info.loc);
console.log("go:", arr);
console.log("go:", arr2);
console.log("go:", getName());
