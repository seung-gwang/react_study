import { arr, arr2, getName, info } from "./common.js";
arr2[0] = 99;
info.loc = "busan";
console.log("go2:", info.loc);
console.log("go2:", arr);
console.log("go2:", arr2);
console.log("go2:", getName());
