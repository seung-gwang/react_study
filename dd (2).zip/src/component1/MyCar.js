import React from 'react';

function MyCar(props) {
    return (
        <div>
            <h1> 오빠 차 뽑았다 </h1>
            <h2> Null 데.리.러.가 </h2>
        </div>
    );
}

export default MyCar;<h1> 오빠차 뽑았다 </h1>